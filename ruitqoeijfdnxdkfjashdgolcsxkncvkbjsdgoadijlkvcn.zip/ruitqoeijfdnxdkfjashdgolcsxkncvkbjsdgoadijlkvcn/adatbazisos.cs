﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ruitqoeijfdnxdkfjashdgolcsxkncvkbjsdgoadijlkvcn
{
    public class Jatekok
    {
        public int id;
        public string nev;
        public string ar;
        public string menny;

        public Jatekok(int id, string nev, string ar, string menny)
        {
            this.id = id;
            this.nev = nev;
            this.ar = ar;
            this.menny = menny;
        }

        public static string connect = "server=localhost;database=projektmunka;user=root;password=;";

        public static List<string> Lekerdez()
        {
            List<string> vissza = new List<string>();
            using (MySqlConnection conn = new MySqlConnection(connect))
            {
                conn.Open();
                string query = "SELECT nev FROM jatekok;";

                using (MySqlCommand cmd = new MySqlCommand(query, conn))
                {
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            vissza.Add(reader["nev"].ToString());
                        }

                    }

                }
            }
            return vissza;
        }
        internal class Adatbazisos
        {
            public static string connectionString = "server=localhost;database=projektmunka;user=root;password=;";
            /*static void Main(string[] args)
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    try
                    {
                        conn.Open();
                        Console.WriteLine("Sikeres kapcsolat az adatbázishoz!");
                    }

                    catch (Exception ex)
                    {
                        Console.WriteLine("Hiba a kapcsolat során: " + ex.Message);
                    }

                    Console.ReadKey();
                }
            }*/
        }
    }
}
