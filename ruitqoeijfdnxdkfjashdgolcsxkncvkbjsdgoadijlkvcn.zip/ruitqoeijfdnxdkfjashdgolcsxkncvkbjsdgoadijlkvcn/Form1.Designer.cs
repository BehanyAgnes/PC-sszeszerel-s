﻿namespace ruitqoeijfdnxdkfjashdgolcsxkncvkbjsdgoadijlkvcn
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            comboBox1 = new ComboBox();
            jatekokBindingSource = new BindingSource(components);
            comboBox2 = new ComboBox();
            label4 = new Label();
            label5 = new Label();
            comboBox3 = new ComboBox();
            numericUpDown1 = new NumericUpDown();
            button1 = new Button();
            jatekokBindingSource1 = new BindingSource(components);
            ((System.ComponentModel.ISupportInitialize)jatekokBindingSource).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)jatekokBindingSource1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Georgia", 24F, FontStyle.Bold, GraphicsUnit.Point, 238);
            label1.ForeColor = Color.FromArgb(192, 0, 192);
            label1.Location = new Point(378, 90);
            label1.Name = "label1";
            label1.Size = new Size(256, 46);
            label1.TabIndex = 0;
            label1.Text = "Rendelőlap";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Georgia", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 238);
            label2.Location = new Point(165, 237);
            label2.Name = "label2";
            label2.Size = new Size(320, 29);
            label2.TabIndex = 1;
            label2.Text = "Videojáték kiválasztása:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Georgia", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 238);
            label3.Location = new Point(306, 311);
            label3.Name = "label3";
            label3.Size = new Size(160, 29);
            label3.TabIndex = 2;
            label3.Text = "Mennyiség:";
            // 
            // comboBox1
            // 
            comboBox1.Font = new Font("Georgia", 14.25F, FontStyle.Italic);
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(508, 234);
            comboBox1.Margin = new Padding(3, 4, 3, 4);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(358, 37);
            comboBox1.TabIndex = 3;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // jatekokBindingSource
            // 
            jatekokBindingSource.DataSource = typeof(Jatekok);
            // 
            // comboBox2
            // 
            comboBox2.Font = new Font("Georgia", 14.25F, FontStyle.Italic, GraphicsUnit.Point, 238);
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "igen", "nem" });
            comboBox2.Location = new Point(509, 380);
            comboBox2.Margin = new Padding(3, 4, 3, 4);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(357, 37);
            comboBox2.TabIndex = 4;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Georgia", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 238);
            label4.Location = new Point(39, 384);
            label4.Name = "label4";
            label4.Size = new Size(458, 29);
            label4.TabIndex = 5;
            label4.Text = "Játék-specifikus ajánlott PC konfig:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Georgia", 14.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 238);
            label5.Location = new Point(261, 456);
            label5.Name = "label5";
            label5.Size = new Size(236, 29);
            label5.TabIndex = 6;
            label5.Text = "Egyedi PC konfig:";
            // 
            // comboBox3
            // 
            comboBox3.Font = new Font("Georgia", 14.25F, FontStyle.Italic, GraphicsUnit.Point, 238);
            comboBox3.FormattingEnabled = true;
            comboBox3.Items.AddRange(new object[] { "igen", "nem" });
            comboBox3.Location = new Point(508, 448);
            comboBox3.Margin = new Padding(3, 4, 3, 4);
            comboBox3.Name = "comboBox3";
            comboBox3.Size = new Size(358, 37);
            comboBox3.TabIndex = 7;
            // 
            // numericUpDown1
            // 
            numericUpDown1.Font = new Font("Georgia", 14.25F);
            numericUpDown1.Location = new Point(509, 308);
            numericUpDown1.Margin = new Padding(3, 4, 3, 4);
            numericUpDown1.Maximum = new decimal(new int[] { 5, 0, 0, 0 });
            numericUpDown1.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            numericUpDown1.Name = "numericUpDown1";
            numericUpDown1.Size = new Size(357, 34);
            numericUpDown1.TabIndex = 8;
            numericUpDown1.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // button1
            // 
            button1.Location = new Point(434, 561);
            button1.Name = "button1";
            button1.Size = new Size(156, 29);
            button1.TabIndex = 9;
            button1.Text = "Rendelés leadása";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // jatekokBindingSource1
            // 
            jatekokBindingSource1.DataSource = typeof(Jatekok);
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(60, 60, 60);
            ClientSize = new Size(944, 801);
            Controls.Add(button1);
            Controls.Add(numericUpDown1);
            Controls.Add(comboBox3);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(comboBox2);
            Controls.Add(comboBox1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)jatekokBindingSource).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
            ((System.ComponentModel.ISupportInitialize)jatekokBindingSource1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private ComboBox comboBox1;
        private ComboBox comboBox2;
        private Label label4;
        private Label label5;
        private ComboBox comboBox3;
        private NumericUpDown numericUpDown1;
        private Button button1;
        private BindingSource jatekokBindingSource;
        private BindingSource jatekokBindingSource1;
    }
}
