namespace ruitqoeijfdnxdkfjashdgolcsxkncvkbjsdgoadijlkvcn
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            List<string> adatok = new List<string>();
            adatok = Jatekok.Lekerdez();// Ez egy adatb�zis lek�rdez�s lehet
            /*for (int i = 0; i < adatok.Count; i++)
            {
                comboBox1.Items.Add(adatok[i]);
            }*/

            foreach (string s in adatok)
            {
                comboBox1.Items.Add(s);
            }
        }
    }
}
